"""
01_prepare_data.py

Loads the raw ward-level population/traffic CSV, does basic cleaning
and validation, and writes a cleaned version to data/wards_clean.csv.

Run this first, before 02_compute_scores.py.
"""

import pandas as pd
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
RAW_FILE = DATA_DIR / "chandigarh_wards_population.csv"
CLEAN_FILE = DATA_DIR / "wards_clean.csv"


def load_raw_data(path: Path) -> pd.DataFrame:
    """Load the raw ward CSV into a DataFrame."""
    df = pd.read_csv(path)
    return df


def validate_columns(df: pd.DataFrame) -> None:
    """Check that all required columns are present."""
    required = {"ward_id", "ward_name", "population", "traffic_score", "has_charger"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Drop duplicates/nulls and enforce sane value ranges."""
    df = df.drop_duplicates(subset="ward_id").copy()
    df = df.dropna(subset=["ward_id", "ward_name", "population", "traffic_score"])

    # traffic_score should be an integer between 1 and 5
    df["traffic_score"] = df["traffic_score"].clip(lower=1, upper=5)

    # has_charger should be strictly 0 or 1
    df["has_charger"] = df["has_charger"].fillna(0).astype(int).clip(lower=0, upper=1)

    # population must be positive
    df = df[df["population"] > 0]

    df = df.sort_values("ward_id").reset_index(drop=True)
    return df


def main():
    print(f"Loading raw data from: {RAW_FILE}")
    df = load_raw_data(RAW_FILE)

    validate_columns(df)
    df_clean = clean_data(df)

    df_clean.to_csv(CLEAN_FILE, index=False)
    print(f"Cleaned data written to: {CLEAN_FILE}")
    print(f"Rows: {len(df_clean)}")
    print(df_clean.head())


if __name__ == "__main__":
    main()

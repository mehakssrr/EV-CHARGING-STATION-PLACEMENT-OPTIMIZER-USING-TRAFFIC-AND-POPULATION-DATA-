"""
03_recommend_locations.py

Reads the scored ward data, selects the top K wards by need_score,
prints a summary table, and saves a bar chart to output/top_wards_chart.png.

Run this after 02_compute_scores.py.
"""

import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
SCORED_FILE = DATA_DIR / "wards_scored.csv"

# Number of new charging stations to recommend
K = 5


def select_top_k(df: pd.DataFrame, k: int) -> pd.DataFrame:
    """Return the top-k wards sorted by need_score, descending."""
    return df.sort_values("need_score", ascending=False).head(k).reset_index(drop=True)


def plot_top_wards(df_top: pd.DataFrame, out_path: Path) -> None:
    """Save a bar chart of need_score for the top wards."""
    plt.figure(figsize=(9, 5))
    bars = plt.bar(df_top["ward_name"], df_top["need_score"], color="teal")

    plt.ylabel("Need Score")
    plt.title(f"Top {len(df_top)} Wards Recommended for New EV Charging Stations")
    plt.xticks(rotation=45, ha="right")

    # Annotate bars with the score value
    for bar in bars:
        height = bar.get_height()
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            height,
            f"{height:.2f}",
            ha="center",
            va="bottom",
            fontsize=9,
        )

    plt.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_path, dpi=150)
    print(f"Chart saved to: {out_path}")


def main():
    print(f"Loading scored data from: {SCORED_FILE}")
    df = pd.read_csv(SCORED_FILE)

    df_top = select_top_k(df, K)

    print(f"\nTop {K} recommended wards for new EV charging stations:\n")
    print(
        df_top[
            ["ward_id", "ward_name", "population", "traffic_score", "has_charger", "need_score"]
        ].to_string(index=False)
    )

    chart_path = OUTPUT_DIR / "top_wards_chart.png"
    plot_top_wards(df_top, chart_path)

    recommendations_path = OUTPUT_DIR / "top_wards_recommendations.csv"
    df_top.to_csv(recommendations_path, index=False)
    print(f"Recommendations saved to: {recommendations_path}")


if __name__ == "__main__":
    main()

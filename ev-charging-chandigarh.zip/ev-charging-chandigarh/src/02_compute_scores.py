"""
02_compute_scores.py

Reads the cleaned ward data, normalizes population and traffic score,
and computes a weighted "need_score" for each ward. Writes the result
to data/wards_scored.csv.

Run this after 01_prepare_data.py.
"""

import pandas as pd
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
CLEAN_FILE = DATA_DIR / "wards_clean.csv"
SCORED_FILE = DATA_DIR / "wards_scored.csv"

# --- Weights: tweak these to change the relative importance of each factor ---
# They don't need to sum to 1, but keeping them that way makes need_score
# easier to interpret as a 0-1-ish scale.
W_POPULATION = 0.5
W_TRAFFIC = 0.4
W_EXISTING_CHARGER_PENALTY = 0.1


def min_max_normalize(series: pd.Series) -> pd.Series:
    """Scale a numeric series to the 0-1 range."""
    min_val, max_val = series.min(), series.max()
    if max_val == min_val:
        # Avoid divide-by-zero if every ward has the same value
        return series.apply(lambda _: 0.5)
    return (series - min_val) / (max_val - min_val)


def compute_need_score(
    df: pd.DataFrame,
    w_p: float = W_POPULATION,
    w_t: float = W_TRAFFIC,
    w_e: float = W_EXISTING_CHARGER_PENALTY,
) -> pd.DataFrame:
    """Add normalized columns and the final need_score column."""
    df = df.copy()
    df["norm_population"] = min_max_normalize(df["population"])
    df["norm_traffic"] = min_max_normalize(df["traffic_score"])

    df["need_score"] = (
        w_p * df["norm_population"]
        + w_t * df["norm_traffic"]
        - w_e * df["has_charger"]
    )

    return df


def main():
    print(f"Loading cleaned data from: {CLEAN_FILE}")
    df = pd.read_csv(CLEAN_FILE)

    df_scored = compute_need_score(df)
    df_scored = df_scored.sort_values("need_score", ascending=False).reset_index(drop=True)

    df_scored.to_csv(SCORED_FILE, index=False)
    print(f"Scored data written to: {SCORED_FILE}")
    print(
        df_scored[
            ["ward_id", "ward_name", "population", "traffic_score", "has_charger", "need_score"]
        ].head(10)
    )


if __name__ == "__main__":
    main()

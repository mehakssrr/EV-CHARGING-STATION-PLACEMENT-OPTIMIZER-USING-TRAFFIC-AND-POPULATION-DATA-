# ⚡ EV Charging Station Placement Helper — Chandigarh

A simple, transparent, data-driven tool that recommends where to place new
EV charging stations in Chandigarh, using ward-level population and a
traffic-importance proxy. Built to be easy to understand and explain in a
report or viva — no heavy GIS or complex ML required.

## Idea

Each ward in Chandigarh is scored using a weighted formula:

```
NeedScore = w_p * NormalizedPopulation + w_t * TrafficScore - w_e * ExistingChargerPenalty
```

- **Population** — more people generally means more potential EV owners.
- **Traffic score (1–5)** — a manually assigned rating of how central /
  commercial / high-footfall a ward is (city centre, markets, bus stands,
  major roads, etc.).
- **Existing charger penalty** — wards that already have a charger get a
  small score reduction, since new stations are more valuable in
  under-served areas.

Wards are ranked by `need_score` and the top **K** are recommended as
priority locations for new charging stations.

This is a simplified version of the multi-criteria decision-making (MCDM) +
GIS approaches used in real EV infrastructure planning research, focused on
the two most easily available and explainable factors.

## Project Structure

```text
ev-charging-chandigarh/
├── data/
│   └── chandigarh_wards_population.csv   # ward-level input data (replace with real data)
├── src/
│   ├── 01_prepare_data.py                # load + clean + validate
│   ├── 02_compute_scores.py              # normalize + compute need_score
│   └── 03_recommend_locations.py         # select top K + generate chart
├── app/
│   └── app.py                            # optional Streamlit interactive app
├── output/                               # generated charts + recommendation CSVs
├── requirements.txt
├── .gitignore
└── README.md
```

## Setup

```bash
git clone <your-repo-url>
cd ev-charging-chandigarh
python -m venv venv
source venv/bin/activate   # on Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Usage

### 1. Run the pipeline scripts (in order)

```bash
python src/01_prepare_data.py
python src/02_compute_scores.py
python src/03_recommend_locations.py
```

This will:
1. Clean and validate `data/chandigarh_wards_population.csv` → `data/wards_clean.csv`
2. Compute normalized scores → `data/wards_scored.csv`
3. Select the top K wards and save a chart + recommendations to `output/`

### 2. (Optional) Run the interactive Streamlit app

```bash
streamlit run app/app.py
```

This lets you adjust the number of stations (K) and the factor weights
(`w_p`, `w_t`, `w_e`) live, with results updating instantly.

## Data

The included `data/chandigarh_wards_population.csv` contains **sample /
placeholder values** for demonstration. For a real submission, replace it
with actual ward-level population figures (e.g. from Census of India /
Chandigarh Administration statistical abstracts) and your own traffic
importance ratings, along with any known existing charger locations.

Required columns:

| Column | Type | Description |
|---|---|---|
| `ward_id` | int | Ward number |
| `ward_name` | str | Ward / area name |
| `population` | int | Ward population |
| `traffic_score` | int (1–5) | Manually assigned traffic/commercial importance |
| `has_charger` | int (0/1) | Whether a charger already exists in that ward |

## Customizing Weights

The default weights in `src/02_compute_scores.py` and `app/app.py` are:

- `w_p = 0.5` (population)
- `w_t = 0.4` (traffic)
- `w_e = 0.1` (existing charger penalty)

Try changing these to see how the recommended wards shift — this makes for
a good "sensitivity analysis" section in a report, without needing extra
math.

## Disclaimer

This is a simplified planning **helper tool** built for educational /
demonstration purposes. It is not an official government plan and should
not be used as the sole basis for real infrastructure investment
decisions.
